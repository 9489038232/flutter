// import 'dart:html';
// import 'package:flutter/src/widgets/form.dart';
import 'dart:async';
//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'homepage.dart';
  
void main() => runApp(MaterialApp(
  home:splash(),
));

class splash extends StatefulWidget {
  

  @override
  _splashState createState() => _splashState();
}

class _splashState extends State<splash> {
  @override
  void initState(){
    super.initState();
    Timer(
      Duration(seconds: 3),
      ()=> Navigator.push(context, MaterialPageRoute(builder:(context)  => MyApp() ))); 
  }
  
  
  

  Widget build(BuildContext context) {
    return Scaffold(
       body: new Container(
        width:double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient
          (
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [
              0.1,
              0.4,
              0.7,
              0.9,
            ],
            colors:[
              Colors.black87,
              Colors.black54,
              Colors.black45,
              Colors.black38,
               ],
          ),
        ),
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[Image.asset(
              "images/flutter.png",height: 100.0,
              ),
              Text('Flutter',
              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize:20,),
              textAlign: TextAlign.center,
              ),
          ],
        ),
       ),
    );
  }
}



