import 'package:flutter/material.dart';
  
class MyApp extends StatefulWidget {
 
  @override
  _State createState() => _State();
}

class _State extends State<MyApp> {
  final  formkey=GlobalKey<FormState>();
  final Scaffoldkey=GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: Scaffoldkey,
      appBar: AppBar(
        title: Text('Flutter login page',style: TextStyle(color: Colors.black,fontSize:25,fontWeight: FontWeight.bold)
      ),
      centerTitle: true,
      backgroundColor:Colors.black45,
      ),
      // ignore: unnecessary_new
      body: new Container(
        padding: EdgeInsets.all(50.0),
        width:double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient
          (
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [
              0.1,
              0.4,
              0.7,
              0.9,
            ],
            colors:[
              Colors.black87,
              Colors.black54,
              Colors.black45,
              Colors.black38,
               ],
          ),
        ),
        child:Center(
          child: new ListView(
            shrinkWrap:true,
            children: <Widget>[Image.asset(
              "images/flutter.png",height: 100.0,
              ),
              Text('Flutter',
              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize:20,),
              textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 50.0,
              ),
              Form(
                key: formkey,
                child: Column(
                  children: <Widget>[
                    TextFormField(
                     validator:(value) {
                    if (value!.isEmpty) {
                        return "ENTER USERNAME";
                      }

                      return null;
                    //  else(value.length>8) {
                    //    return "username should not exceed 8 characters";
                    //  }
                     }, 
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  icon: Icon(Icons.account_circle,color: Colors.white),
                  hintText: "user name",
                  hintStyle: TextStyle(
                    color: Colors.white70,
                  ),
                ),
              ),
               SizedBox(
                height: 50.0,
              ),
               TextFormField(
                 validator: (Value){
                   if (Value!.isEmpty) {
                        return "ENTER password";
                      }
                      return null;
                 },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  icon: Icon(Icons.lock,color: Colors.white),
                  hintText: "password",
                  hintStyle: TextStyle(
                    color: Colors.white70,
                  ),
                ),
                obscureText:true,
                maxLength: 10,
              ),
                  ],
                ),
              ),
              
            SizedBox(
                height: 50.0,
              ),
              Container(
                 decoration: BoxDecoration(
                    gradient: LinearGradient
          (
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [
              0.1,
              0.4,
              0.7,
              0.9,
            ],
            colors:[
              Colors.black87,
              Colors.black54,
              Colors.black45,
              Colors.black38,
               ],
          ),
         ),
         
         child: ButtonTheme(
           buttonColor: Colors.white10,
           height: 50.0,
           minWidth: 100.0,
          
           child: RaisedButton(
           onPressed: (){
             if (formkey.currentState!.validate()) {
               Scaffoldkey.currentState!.showSnackBar(SnackBar(
                 content: Text("login successful"),
               ));
               Navigator.pushReplacement(
                 context,
                MaterialPageRoute(
                  builder: (context) => Homepage()));
                  
             }
             else {
                Scaffoldkey.currentState!.showSnackBar(SnackBar(
                 content: Text("enter a valid user name and password"),
                 ));
             }
           },
           child: Text("login",style:TextStyle(color:Colors.white) ,
           ),
           ),
           
         ),

                ),
              SizedBox(
                height: 20.0,
              ),
             Text(
               "Forgot password?",
               style: TextStyle(color:Colors.white,decoration: TextDecoration.underline),
               textAlign: TextAlign.center,
             ),
             SizedBox(
                height: 20.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Image.asset(
                    "images/google.png",
                    height: 30.0,
                  ),
                  SizedBox(
                width: 20.0,
              ),
              Image.asset(
                    "images/download.png",
                    height: 30.0,
                  ),
                ],
              ) ,
            ],
           ),
        ),
      ),
      
    );
  }
}

class Homepage extends StatelessWidget {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text("Flutter Home Page",style: TextStyle(color: Colors.black,fontSize:25,fontWeight: FontWeight.bold)
        ),
      centerTitle: true,
      backgroundColor:Colors.black45,
      ),
     
        body: new Container(
         padding: EdgeInsets.all(50.0),
        width:double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient
          (
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [
              0.1,
              0.4,
              0.7,
              0.9,
            ],
            colors:[
              Colors.black87,
              Colors.black54,
              Colors.black45,
              Colors.black38,
               ],
          ),
        ),
       
        child:Center(
        child: new  ListView(
            shrinkWrap:true,
          children:<Widget> [
            Image.asset(
              "images/flutter.png",height: 100.0,
              ),
              SizedBox(
                height: 50.0,
              ), 
              Text("FLUTTER-INTRODUCTION",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ),
                SizedBox(
                height: 20.0,
              ),
               Text("FLUTTER-INSTALLATION",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ),
              SizedBox(
                height: 20.0,
              ), 
              Text("FLUTTER-CONCEPTS",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ),
               SizedBox(
                height: 20.0,
              ), 
              Text("FLUTTER-DART PROGRAMMING",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ),
                SizedBox(
                height: 20.0,
              ), 
              Text("FLUTTER-CONCEPTS OF LAYOTS",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ),
              SizedBox(
                height: 20.0,
              ),
              Text("FLUTTER-CONCEPTS OF WIDGETS",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ), 
               SizedBox(
                height: 20.0,
              ),
              Text("FLUTTER-APPLICATION DEVELOPEMENT",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ), 
              SizedBox(
                height: 20.0,
              ),
              Text("FLUTTER-CONCLUSION",style: TextStyle(color:Colors.white,),
               textAlign: TextAlign.center,
               ), 
               SizedBox(
                height: 20.0,
              ),
               ButtonTheme(
           buttonColor: Colors.black12,
           height: 50.0,
           minWidth: 100.0,
          
           child: FlatButton(
           onPressed: (){ 
              Navigator.pushReplacement(
                 context,
                MaterialPageRoute(
                  builder: (context) => MyApp()));
           },
              child: Text(" back to login page",style:TextStyle(color:Colors.black,decoration: TextDecoration.underline)
           ),
           ),
               ),
          ],
          ),
        ),
      
    ),
    );
  }
}